<?php

function tender_get_default_book_cover_svg()
{
	return '<svg
		viewBox="0 0 304 441"
		fill="none"
		xmlns="http://www.w3.org/2000/svg"
	>
		<rect width="304" height="441" fill="#D9D9D9" />
		<circle
			cx="152"
			cy="223"
			r="79.5"
			stroke="white"
			stroke-width="13"
		/>
		<path
			d="M203.437 260.438C201.104 260.312 198.833 260.146 196.625 259.938C194.458 259.688 192.479 259.354 190.687 258.938C188.896 258.521 187.375 257.979 186.125 257.312C184.917 256.604 184.125 255.729 183.75 254.688L149.187 169.312C148.479 169.354 147.792 169.646 147.125 170.188C146.833 175.354 145.25 179.5 142.375 182.625L143.812 186.312L117.437 252.625C115.771 256.792 110.646 259.396 102.062 260.438C101.812 261.021 101.687 261.542 101.687 262C101.687 262.5 101.812 263 102.062 263.5C106.812 263.333 110.625 263.208 113.5 263.125C116.417 263.042 118.417 263 119.5 263C120.458 263 122.625 263.042 126 263.125C129.417 263.208 134.042 263.333 139.875 263.5C140.125 263 140.25 262.5 140.25 262C140.25 261.542 140.125 261.021 139.875 260.438C136.417 260.104 133.604 259.75 131.437 259.375C129.271 258.958 127.583 258.521 126.375 258.062C125.167 257.604 124.354 257.104 123.937 256.562C123.521 255.979 123.312 255.333 123.312 254.625C123.312 254.167 123.396 253.708 123.562 253.25L132.687 230.375C137.312 230.292 141.042 230.229 143.875 230.188C146.75 230.146 148.729 230.125 149.812 230.125C152.187 230.125 154.292 230.146 156.125 230.188C158 230.188 159.604 230.208 160.937 230.25L170 253.25C170.208 253.875 170.312 254.354 170.312 254.688C170.312 255.812 169.729 256.812 168.562 257.688C167.437 258.562 166.042 259.167 164.375 259.5L157.625 260.438C157.375 261.021 157.25 261.542 157.25 262C157.25 262.5 157.375 263 157.625 263.5C161.167 263.375 164.75 263.271 168.375 263.188C172.042 263.104 175.792 263.062 179.625 263.062C183.458 263.062 187.333 263.104 191.25 263.188C195.208 263.271 199.271 263.375 203.437 263.5C203.729 262.917 203.875 262.417 203.875 262C203.875 261.75 203.833 261.5 203.75 261.25C203.667 261 203.562 260.729 203.437 260.438ZM149.812 225.25C143.771 225.25 138.792 225.167 134.875 225L146.75 194.375H147L158.937 225.125C156.687 225.208 153.646 225.25 149.812 225.25ZM146.875 200.938L138.562 222.562C143.604 222.812 149.146 222.854 155.187 222.688L146.875 200.938ZM205.375 258.125C206.417 260.625 206.375 263.271 205.25 266.062H155.687C154.687 263.188 154.687 260.542 155.687 258.125C160.229 257.875 163.437 257.417 165.312 256.75C167.187 256.042 167.833 254.917 167.25 253.375L159.062 232.688C151.354 232.396 143.104 232.479 134.312 232.938L126.25 253.625C126 254.333 126.187 254.979 126.812 255.562C127.479 256.104 128.542 256.542 130 256.875C131.458 257.208 133.167 257.479 135.125 257.688C137.083 257.896 139.292 258.042 141.75 258.125C142.792 260.625 142.75 263.271 141.625 266.062C127.958 265.562 114.187 265.562 100.312 266.062C99.1875 263.271 99.1458 260.625 100.187 258.125C108.771 257.125 113.625 255.25 114.75 252.5L141.125 186.188C140.958 185.854 140.625 185.104 140.125 183.938C139.667 182.729 139.396 181.938 139.312 181.562C142.562 178.271 144.354 174.021 144.687 168.812C148.354 167.021 152.667 166 157.625 165.75L192.687 252.75C193.479 254.708 194.729 256.021 196.437 256.688C198.146 257.312 201.125 257.792 205.375 258.125Z"
			fill="white"
		/>
	</svg>';
}

function tender_render_mini_book_markup($book_id, $extra_classes = '')
{
	$book_id = (int) $book_id;

	if (!$book_id) {
		return '<p class="miniatura-placeholder">' . esc_html__('No books selected', 'tender-library') . '</p>';
	}

	$image_id = carbon_get_post_meta($book_id, 'tender_book_cover');
	$image = null;
	if ($image_id) {
		$image = wp_get_attachment_image($image_id, 'medium');
	}

	$author = carbon_get_post_meta($book_id, 'tender_book_author');
	$classes = trim('wp-block-tender-a-library-mini-book tender-book-preview ' . $extra_classes);

	ob_start();
	?>
	<div class="<?php echo esc_attr($classes); ?>">
		<a href="<?php echo esc_url(get_permalink($book_id)); ?>" class="cover">
			<?php if ($image) : ?>
				<?php echo $image; ?>
			<?php else : ?>
				<?php echo tender_get_default_book_cover_svg(); ?>
			<?php endif; ?>
		</a>
		<div class="book-info">
			<a class="title" href="<?php echo esc_url(get_permalink($book_id)); ?>"><?php echo esc_html(get_the_title($book_id)); ?></a>

			<?php if ($author) : ?>
				<div class="author"><?php echo esc_html($author); ?></div>
			<?php endif; ?>
		</div>
		<div class="book-availability">
			<?php if (tender_can_book_be_lent($book_id)) : ?>
				<span class="available"><?php esc_html_e('Available', 'tender-library'); ?></span>
			<?php else : ?>
				<span class="unavailable"><?php esc_html_e('Not Available', 'tender-library'); ?></span>
			<?php endif; ?>
		</div>
	</div>
	<?php

	return ob_get_clean();
}

function tender_mini_book_render_callback($block_attributes, $block_content)
{
	$book_id = get_the_ID();

	if (!$book_id) {
		return '<p class="miniatura-placeholder">' . esc_html__('No books selected', 'tender-library') . '</p>';
	}

	$block_classes = tender_get_block_classes($block_attributes);

	return tender_render_mini_book_markup($book_id, $block_classes);
}
